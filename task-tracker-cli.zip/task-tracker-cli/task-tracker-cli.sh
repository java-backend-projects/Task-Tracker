#!/bin/bash
if [ "$(expr substr $(uname -s) 1 5)" == "Linux" ]; then
  java -jar task-tracker-cli.jar "$@"
elif [ "$(expr substr $(uname -s) 1 10)" == "MINGW32_NT" ]; then
  java -jar task-tracker-cli.jar "$@"
elif [ "$(expr substr $(uname -s) 1 10)" == "MINGW64_NT" ]; then
  java -jar task-tracker-cli.jar "$@"
else
  echo "Unsupported OS"
fi